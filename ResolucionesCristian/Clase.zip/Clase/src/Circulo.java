import java.io.IOException;

public class Circulo {
	double radio;

	// las excepcione se capturan, si no puedo resolverlas en donde se producen
	// entoneces paso la excepcion al llamador y si este no puede, se lo envio al llamador
	
	// aca en un constructor no es posible usar ifs.
	// si o si se necesita excepciones
	/*public Circulo(double radio) throws RadioNegativoException, IOException{
		if(radio < 0 ){
			throw new RadioNegativoException();
		}
		//throw new IOException();
		this.radio = radio;
	}

	
	// en un set seria mejor una excepcion,
	// aunque puedo manejarlo con ifs
	public void setRadio(double radio) {
		if (radio < 0)
			System.out.println("error");
		else
			this.radio = radio;

	}*/
	public Circulo(double radio) throws RadioNegativoException, IOException{
		try{
			setRadio(radio);
		}catch(Exception e){
			throw new CirculoException(e);
		}
		//throw new IOException();
		this.radio = radio;
	}

	
	// en un setAtributo seria mejor una excepcion,
	// aunque puedo manejarlo con ifs
	public void setRadio(double radio) {
		if (radio < 0)
			throw new RadioNegativoException();
		else
			this.radio = radio;

	}
	
}
