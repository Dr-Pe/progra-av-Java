import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

//USOS METODOS TreeSet Y HashSet

public class testHash {
	public static void main(String[] args) {
		// Set<Integer> conj = new HashSet<Integer>();
		Set<Integer> conj = new TreeSet<Integer>();
		// add indexado y al final
		conj.add(0);
		conj.add(1);
		conj.add(5);
		conj.add(3);

		// conj.add(1, 3); no permite add por indice

		System.out.println(conj);
		// remove por indice y por valor(objeto)
		conj.remove(1);
		conj.remove((Integer) 5);

		System.out.println(conj);

		// busquedas; contiene X objeto, devolver indice de X valor

		System.out.println(conj.contains((Integer) 1));

		/*
		 * a razon que no usa indices 
		 * conj.get(ind)
		 * conj.add(ind,val)
		 * conj.remove(ind)
		 * conj.indexOf(val)
		 */
		
		// recorrido de conj
		for (int x : conj) {
			System.out.print(x + 1 + " ");
		}

		// imprimir, por pantalla o en archivo
		conj.toString();

		// borrar conj
		conj.clear();

		System.out.println();

		// tamano de conj, si esta vacia
		System.out.println(conj.size());
		System.out.println(conj.isEmpty());

		System.out.println("======================================================");
		//HashCode en integer coincide con el valor
		//en string no.
		
		///TreeSet usa orden alfabetico
		///HashCode usa comparacion entre los Hashcode
		
		//Set<String> conj2 = new TreeSet<String>();
		Set<String> conj2 = new HashSet<String>();

		conj2.add("a");
		conj2.add("b");
		conj2.add("e");
		conj2.add("p");

		System.out.println(conj2);

		conj2.remove("a");
		conj2.remove((String) "p");

		System.out.println(conj2);

		System.out.println(conj2.contains((String) "q"));

		for (String x : conj2) {
			System.out.print(x + " ");
		}

		conj2.toString();

		conj2.clear();

		System.out.println();

		System.out.println(conj2.size());
		System.out.println(conj2.isEmpty());

		//ver.
		//HashCode es mas rapido ya que compara unicamente por hashcode
		//TreeSet es mas lento porue para comparar necesita llevar todo el arbol para comparar
	
	
	
	}
}
