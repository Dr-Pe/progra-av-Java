
//si hago extends de RuntimeException directamente solo lanzo la excepcion en setRadio <0 y listo.
//solo si no quiero enviar la excepcion a donde fue llamado el metodo.

//osea si radio es menor a 0, porque seguiria enviando la excepcion a donde fue llamado 
//si directamente la puedo resolver en el mismo metodo?

public class RadioNegativoException extends RuntimeException {
	private static final long serialVersionUID = -4;
	
	
	public RadioNegativoException(String msj){
		super(msj);
	}
	
	public RadioNegativoException(){
		super("Error radio negativo");
	}
	
}

