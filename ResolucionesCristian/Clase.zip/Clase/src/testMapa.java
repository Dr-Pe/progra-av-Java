import java.util.HashMap;
import java.util.Map;

//USOS METODOS HashMap y TreeMap

public class testMapa {
	public static void main(String[] args) {
		//Map< String, Integer > alumnos = new treeMap< String, Integer>();
		Map< String, Integer > alumnos = new HashMap< String, Integer>();
		
		
		//agregar
		alumnos.put("Yo", 21);
		
		// contiene por key y value
		System.out.println(alumnos.containsKey("Yo"));
		System.out.println(alumnos.containsValue(21));
		
		// repetir: si key esta; reemplaza por nuevo valor
		alumnos.put("Yo", 20);

		//obtener valu por key
		System.out.println(alumnos.get("Yo"));
		
		// 
		for(String x : alumnos.keySet()){
			System.out.println(x);
		}
		
		//metodos basicos
		alumnos.size();
		//alumnos.clear();
		alumnos.isEmpty();
		
		//obtener claves; keySet, es set porque la claves no tienen repetidos
		alumnos.keySet();
		//obtener values: 
		alumnos.values();
		//entradas  entrySet devuelve lista de keys y claves, y ahi obtengo lo que necesite
		// ver funciones entry.
		System.out.println(alumnos.entrySet().size() );
		
		//imprimir
		alumnos.toString();
		

		System.out.println();
		System.out.println();
		// devuelve el 2do parametro si no lo encuentra
		System.out.println(alumnos.getOrDefault("Yo", 2));

		//evita pisar una clave si ya estaba
		//si devuelve null, entonces agrega, si la key ya esta, no agrega y devuelve el valor de la key
		
		System.out.println(alumnos);
		System.out.println(alumnos.putIfAbsent("Yo", 20));
		System.out.println(alumnos);

		/*
		int difFiguritas(int[] A, int[] B)
		int s=A.lenght, t;
		
		for(int i = 0; i<s; i++)
			t=A[i];
			for(int x : A)
				if(t == x && t<1)
					A[i]=0;
					s--;
					
				//s-= t==x && t<1 ? 1, A[i]=0:0
		return s+difFiguritas(a,null);
		*/
		
	}
}
