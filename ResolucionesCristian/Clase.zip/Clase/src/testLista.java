import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

//USOS METODOS ArrayList Y LinkedList

public class testLista {
	public static void main(String[] args) {

		List<Integer> lista = new LinkedList<Integer>();
		// add indexado y al final
		lista.add(0);
		lista.add(1);
		lista.add(5);
		lista.add(3);
		lista.add(1, 3);

		System.out.println(lista);
		// remove por indice y por valor(objeto)
		lista.remove(1);
		lista.remove((Integer) 5);

		System.out.println(lista);

		// busquedas; contiene X objeto, devolver indice de X valor

		System.out.println(lista.contains((Integer) 1));
		System.out.println(lista.indexOf(1));
		// recuperar elemento segun indice
		int test = lista.get(2);
		System.out.println(test);

		// recorrido de lista
		for (int x : lista) {
			System.out.print(x + 1 + " ");
		}

		// imprimir, por pantalla o en archivo
		lista.toString();

		// borrar lista
		lista.clear();

		System.out.println();

		// tamano de lista, si esta vacia
		System.out.println(lista.size());
		System.out.println(lista.isEmpty());

		// == compara por referencias
		// equals compara por contenido

		// siempre armar equals, toString y HashCode
		// si se quiere ordenar elementos, los elementos deben ser comparables,
		// .compareTo

		System.out.println("==============================");
		List<Integer> listaArray = new ArrayList<Integer>();
		// add indexado y al final
		listaArray.add(0);
		listaArray.add(1);
		listaArray.add(5);
		listaArray.add(3);
		listaArray.add(1, 3);

		System.out.println(listaArray);
		// remove por indice y por valor(objeto)
		listaArray.remove(1);
		listaArray.remove((Integer) 5);

		System.out.println(listaArray);

		// busquedas; contiene X objeto, devolver indice de X valor

		System.out.println(listaArray.contains((Integer) 1));
		System.out.println(listaArray.indexOf(1));
		// recuperar elemento segun indice
		int test2 = listaArray.get(2);
		System.out.println(test2);

		// recorrido de lista
		for (int x : listaArray) {
			System.out.print(x + 1 + " ");
		}

		// imprimir, por pantalla o en archivo
		listaArray.toString();

		// borrar lista
		listaArray.clear();

		System.out.println();

		// tamano de lista, si esta vacia
		System.out.println(listaArray.size());
		System.out.println(listaArray.isEmpty());
		
		//List<Float> qwe = new List<Float>();
		// List  interfaz;
		
		
		
	}
}
