package excepciones;

public class Excepciones {
	public static void main(String[] args) {
		Circulo c = new Circulo(-1);
		System.out.println(c);
	}
}
