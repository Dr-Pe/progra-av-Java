import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class excepciones {

	public static void main(String[] args) {
		int i = 5;
		int j = 0;
		
		List<Integer> lista = new ArrayList<Integer>();
	
		
//Excepciones capturables// si o si tratadas
		/*try{
			lista.add(3,10);
			System.out.println(i/j);
		
			System.out.println("Corta antes y ejecuta directmente catch");

		}catch(ArithmeticException ae){
			System.out.println("error");
			//ingrese valor nuevamente
		}catch(IndexOutOfBoundsException io){
			//guardo info
			//proceso info
			io.printStackTrace();//muestra msj error por defecto pero el codigo va a seguir a pesar dle error
			System.exit(1); 		//con esto mato al programa
		}catch(Exception e){
			//captura todas las exception menos las anteriores
		}
		
		//si ejecuta bien try, o ejecuta mal y v a catch, se ejecuta finally siempre
		finally{}*/
		
//errores try catch y lanzar exceptions en metodos
		//sol 1: try catch
		//sol 2: throws IOException {} en metodo, para enviar la excepcion una clase antes.
		//FileWriter x = new FileWriter("x");
		//fileWriter();
		
		
//excepciones no capturables/no necesariamente tratadas
		//no se puede capturar y directamente corta el programa
		throw new RuntimeException();
		//String x = null;
		//System.out.println(x.toCharArray());
	}
	
	public static void fileWriter() throws IOException{
		throw new IOException("no se encontro le archivo");
	}
	
	public static void fileWriter2() throws IOException{	//f2
		//este caso esta mal, ya que siempre va  a lanzar la exception
		//si hay if dentro del try talvez es util
		try{
			throw new IOException("no se encontro le archivo");// f1
		}catch(Exception e){
			//algo
		}
	}
	//f1 lanza exception a un clase superior con el throws IOException del fileWriter(f2)
	// pero hago el catch dentro del metodo, entonces f2 no tiene sentido ya que no estoy
	// devolviendo alguna excepcion
	
	
	
	
}
